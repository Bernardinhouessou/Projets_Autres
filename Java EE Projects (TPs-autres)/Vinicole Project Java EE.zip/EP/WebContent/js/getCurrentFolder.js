// This example shows folder manipulation routines: it lists 
// the contents of the current folder. 
// Created with Antechinus� JavaScript Editor 
// Copyright� 2009 C Point Pty Ltd 

document.getElementById('fileInput').onchange=function(){
    // On r�cup�re la liste des fichiers
    var listeFichiers = document.getElementById('fileInput').files;
    for ( var i = 0; i < listeFichiers.length; i ++ )
    {
        var unFichier = listeFichiers[i];
        var message = unFichier.name;
        alert( message );
    }}